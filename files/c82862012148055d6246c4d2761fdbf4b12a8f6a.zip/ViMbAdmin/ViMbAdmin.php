<?php namespace App\SupportedApps\ViMbAdmin;

class ViMbAdmin extends \App\SupportedApps
{
}
