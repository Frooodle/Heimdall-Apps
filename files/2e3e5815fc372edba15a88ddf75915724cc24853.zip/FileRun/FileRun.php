<?php namespace App\SupportedApps\FileRun;

class FileRun extends \App\SupportedApps
{
}
