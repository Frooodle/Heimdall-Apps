<?php namespace App\SupportedApps\cPanel;

class cPanel extends \App\SupportedApps
{
}
