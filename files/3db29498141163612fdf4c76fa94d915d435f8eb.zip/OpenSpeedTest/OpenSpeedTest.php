<?php namespace App\SupportedApps\OpenSpeedTest;

class OpenSpeedTest extends \App\SupportedApps
{
}
