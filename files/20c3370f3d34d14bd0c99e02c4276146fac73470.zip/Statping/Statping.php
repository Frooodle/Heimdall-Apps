<?php namespace App\SupportedApps\Statping;

class Statping extends \App\SupportedApps
{
}
