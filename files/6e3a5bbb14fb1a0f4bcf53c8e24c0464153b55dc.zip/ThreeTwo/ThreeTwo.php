<?php namespace App\SupportedApps\ThreeTwo;

class ThreeTwo extends \App\SupportedApps {

}