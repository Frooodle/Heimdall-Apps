<?php namespace App\SupportedApps\ZoneMinder;

class ZoneMinder extends \App\SupportedApps
{
}
