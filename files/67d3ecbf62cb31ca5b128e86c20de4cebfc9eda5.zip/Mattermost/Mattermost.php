<?php namespace App\SupportedApps\Mattermost;

class Mattermost extends \App\SupportedApps
{
}
