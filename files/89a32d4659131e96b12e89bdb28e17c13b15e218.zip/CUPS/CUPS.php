<?php namespace App\SupportedApps\CUPS;

class CUPS extends \App\SupportedApps
{
}
