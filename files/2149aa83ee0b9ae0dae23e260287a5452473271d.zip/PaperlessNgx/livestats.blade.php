<ul class="livestats">
    <li>
        <span class="title">Documents</span>
        <strong>{!! $documentCount !!}</strong>
    </li>
</ul>
