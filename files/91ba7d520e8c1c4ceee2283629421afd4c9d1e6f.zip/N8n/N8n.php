<?php namespace App\SupportedApps\N8n;

class N8n extends \App\SupportedApps
{
}
