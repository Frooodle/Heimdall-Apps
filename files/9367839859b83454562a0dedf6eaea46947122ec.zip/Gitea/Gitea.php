<?php namespace App\SupportedApps\Gitea;

class Gitea extends \App\SupportedApps
{
}
