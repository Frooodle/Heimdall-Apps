<?php namespace App\SupportedApps\Splunk;

class Splunk extends \App\SupportedApps
{
}
