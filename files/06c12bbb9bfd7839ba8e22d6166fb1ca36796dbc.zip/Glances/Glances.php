<?php namespace App\SupportedApps\Glances;

class Glances extends \App\SupportedApps
{
}
