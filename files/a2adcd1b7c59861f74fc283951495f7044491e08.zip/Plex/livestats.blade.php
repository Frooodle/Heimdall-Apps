<ul class="livestats">
    <li>
        <span class="title">Recent</span>
        <strong>{!! $recently_added ?? '' !!}</strong>
    </li>
    <li>
        <span class="title">On Deck</span>
        <strong>{!! $on_deck ?? '' !!}</strong>
    </li>

</ul>
