<?php namespace App\SupportedApps\RSSHub;

class RSSHub extends \App\SupportedApps {

}
