<?php namespace App\SupportedApps\Chronograf;

class Chronograf extends \App\SupportedApps
{
}
